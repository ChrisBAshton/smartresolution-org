# Test Module

This module is meant to test the SmartResolution module support. It adds nothing useful and should be removed from production.